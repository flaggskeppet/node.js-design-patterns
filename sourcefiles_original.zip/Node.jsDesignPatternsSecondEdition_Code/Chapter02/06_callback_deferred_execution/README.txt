This example shows deferred execution with callbacks.

To run the example launch:

  node test
