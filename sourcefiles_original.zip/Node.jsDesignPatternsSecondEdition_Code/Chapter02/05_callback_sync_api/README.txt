This example shows synchronous api with callbacks.

To run the example launch:

  node test
