"use strict";

const logger = require('./logger_function');

logger('This is an informational message');
logger.verbose('This is a verbose message');
