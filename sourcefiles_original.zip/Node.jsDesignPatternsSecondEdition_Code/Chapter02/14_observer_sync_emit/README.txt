This example shows a synchronous event emitter.

To run the example launch:

  node test
