This example shows unpredictable sync/async callbacks.

To run the example launch:

  node test
