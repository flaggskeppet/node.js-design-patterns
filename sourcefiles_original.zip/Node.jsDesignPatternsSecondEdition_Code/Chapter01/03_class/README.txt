In this folder you can find several examples that show how to use the class definition.

To execute them simply run:

  node <filename.js>

(e.g. node 01.js)
