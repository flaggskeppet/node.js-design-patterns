"use strict";

for (let i=0; i < 10; i++) {
  // do something here
}
console.log(i); // ReferenceError: i is not defined
