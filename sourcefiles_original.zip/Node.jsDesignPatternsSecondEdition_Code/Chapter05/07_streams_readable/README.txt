This example shows how to implement a readable stream by extending the Stream.Readable class.

To run the example you need to:

  npm install
  node generateRandom
