This example shows how to implement the decorator pattern using object augmentation.
To run the example you can simply launch:

  node decorator
