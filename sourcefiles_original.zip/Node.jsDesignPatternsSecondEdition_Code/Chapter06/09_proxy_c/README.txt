This example illustrates how to create a proxy using monkey patching.

To run the example simply execute:

  node test
