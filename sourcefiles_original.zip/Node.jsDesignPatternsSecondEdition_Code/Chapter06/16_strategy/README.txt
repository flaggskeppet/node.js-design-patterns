This sample shows how to use the Strategy pattern to 
create a configuration manager that supports various file formats.

To install all the dependencies:
  npm install

To run the sample:
   node configTest
