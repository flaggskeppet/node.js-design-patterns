This example shows how to implement a simple factory function.
To run the example you have to launch:

  node factory
