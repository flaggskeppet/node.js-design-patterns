This example show a simple usage of generators.

To run it use:

node index