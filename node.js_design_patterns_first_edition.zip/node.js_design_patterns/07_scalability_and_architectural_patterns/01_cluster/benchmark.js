const siege = require("siege");

siege()
  .wait(3000)
  .on(8080)
  .for(10000).times
  .get('/')
  .attack()