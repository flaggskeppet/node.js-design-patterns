var cluster = require('cluster');
var os = require('os');

if(cluster.isMaster) {
  var cpus = os.cpus().length;
  console.log('Number of cpus: ', cpus);
  for (var i = 0; i < cpus; i++) {
    cluster.fork(); // Cluster is forking itself (creating a new process)
  }
} else {
  require('./app'); // If this a fork (not the master) init the app
}
