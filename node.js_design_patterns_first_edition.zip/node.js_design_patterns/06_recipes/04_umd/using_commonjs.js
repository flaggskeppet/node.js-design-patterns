var umdModule = require('./umdModule');
var hello = umdModule.sayHello('World');
console.log(hello);
