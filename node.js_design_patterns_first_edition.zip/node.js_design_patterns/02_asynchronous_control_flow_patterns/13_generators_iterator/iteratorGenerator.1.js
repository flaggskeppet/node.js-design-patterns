const fruits = ['apple', 'orange', 'watermelon'];
for(var i = 0; i < fruits.length; i++) {
  console.log(fruits[i]);
};
fruits.forEach(element => {
  console.log(element);
  });

