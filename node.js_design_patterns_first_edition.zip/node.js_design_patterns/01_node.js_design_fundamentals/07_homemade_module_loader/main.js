var moduleA = require('./moduleA');
moduleA.run();
