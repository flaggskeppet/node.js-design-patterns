
exports.log = function() {
  console.log("From module B: the homemade require works!");
}
